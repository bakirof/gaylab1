using System.Reflection;
using System;

[assembly: AssemblyTitle("Remoting Master")]
[assembly: AssemblyDescription("Demonstrates .NET Remoting")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Elm�Soft")]
[assembly: AssemblyProduct("")]
[assembly: AssemblyCopyright("2005")]
[assembly: AssemblyTrademark("Elm�Soft")]
[assembly: AssemblyCulture("")]		
[assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
[assembly: AssemblyKeyName("")]
[assembly: CLSCompliant(true)]
