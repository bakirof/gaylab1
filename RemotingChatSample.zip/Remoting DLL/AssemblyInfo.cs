
using System;
using System.Reflection;

[assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyTitle("Remoting DLL")]
[assembly: AssemblyDescription(".NET Remoting demo")]
[assembly: AssemblyCompany("Elm�Soft")]
[assembly: AssemblyProduct("Remoting demo")]
[assembly: AssemblyCopyright("Copyright Elm�Soft 2005")]
[assembly: CLSCompliant(true)]




